-- MySQL dump 10.13  Distrib 9.3.0, for macos15.2 (arm64)
--
-- Host: yamanote.proxy.rlwy.net    Database: restaurant_la_mangeoire
-- ------------------------------------------------------
-- Server version	9.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Clients`
--

DROP TABLE IF EXISTS `Clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Clients` (
  `ClientID` int NOT NULL AUTO_INCREMENT,
  `Nom` varchar(100) NOT NULL,
  `Prenom` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Telephone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ClientID`),
  UNIQUE KEY `Email` (`Email`),
  KEY `IDX_Clients_Email` (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Clients`
--

LOCK TABLES `Clients` WRITE;
/*!40000 ALTER TABLE `Clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `Clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Commandes`
--

DROP TABLE IF EXISTS `Commandes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Commandes` (
  `CommandeID` int NOT NULL AUTO_INCREMENT,
  `ReservationID` int NOT NULL,
  `MenuID` int NOT NULL,
  `Quantite` int NOT NULL,
  PRIMARY KEY (`CommandeID`),
  KEY `ReservationID` (`ReservationID`),
  KEY `MenuID` (`MenuID`),
  CONSTRAINT `Commandes_ibfk_1` FOREIGN KEY (`ReservationID`) REFERENCES `Reservations` (`ReservationID`) ON DELETE CASCADE,
  CONSTRAINT `Commandes_ibfk_2` FOREIGN KEY (`MenuID`) REFERENCES `Menus` (`MenuID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Commandes`
--

LOCK TABLES `Commandes` WRITE;
/*!40000 ALTER TABLE `Commandes` DISABLE KEYS */;
/*!40000 ALTER TABLE `Commandes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employes`
--

DROP TABLE IF EXISTS `Employes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Employes` (
  `EmployeID` int NOT NULL AUTO_INCREMENT,
  `Nom` varchar(100) NOT NULL,
  `Prenom` varchar(100) NOT NULL,
  `Poste` varchar(50) NOT NULL,
  `Salaire` decimal(10,2) NOT NULL,
  `DateEmbauche` date NOT NULL,
  PRIMARY KEY (`EmployeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employes`
--

LOCK TABLES `Employes` WRITE;
/*!40000 ALTER TABLE `Employes` DISABLE KEYS */;
/*!40000 ALTER TABLE `Employes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Menus`
--

DROP TABLE IF EXISTS `Menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Menus` (
  `MenuID` int NOT NULL AUTO_INCREMENT,
  `NomItem` varchar(100) NOT NULL,
  `Description` text,
  `Prix` decimal(10,2) NOT NULL,
  PRIMARY KEY (`MenuID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Menus`
--

LOCK TABLES `Menus` WRITE;
/*!40000 ALTER TABLE `Menus` DISABLE KEYS */;
/*!40000 ALTER TABLE `Menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Paiements`
--

DROP TABLE IF EXISTS `Paiements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Paiements` (
  `PaiementID` int NOT NULL AUTO_INCREMENT,
  `ReservationID` int NOT NULL,
  `Montant` decimal(10,2) NOT NULL,
  `DatePaiement` date NOT NULL,
  `ModePaiement` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`PaiementID`),
  KEY `ReservationID` (`ReservationID`),
  CONSTRAINT `Paiements_ibfk_1` FOREIGN KEY (`ReservationID`) REFERENCES `Reservations` (`ReservationID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Paiements`
--

LOCK TABLES `Paiements` WRITE;
/*!40000 ALTER TABLE `Paiements` DISABLE KEYS */;
/*!40000 ALTER TABLE `Paiements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Reservations`
--

DROP TABLE IF EXISTS `Reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reservations` (
  `ReservationID` int NOT NULL AUTO_INCREMENT,
  `ClientID` int DEFAULT NULL,
  `TableID` int DEFAULT NULL,
  `DateReservation` datetime NOT NULL,
  `Statut` enum('Réservée','Annulée') DEFAULT 'Réservée',
  `nom_client` varchar(100) DEFAULT NULL,
  `email_client` varchar(100) DEFAULT NULL,
  `nb_personnes` int DEFAULT NULL,
  `telephone` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ReservationID`),
  KEY `ClientID` (`ClientID`),
  KEY `TableID` (`TableID`),
  KEY `IDX_Reservations_Date` (`DateReservation`),
  CONSTRAINT `Reservations_ibfk_1` FOREIGN KEY (`ClientID`) REFERENCES `Clients` (`ClientID`) ON DELETE CASCADE,
  CONSTRAINT `Reservations_ibfk_2` FOREIGN KEY (`TableID`) REFERENCES `TablesRestaurant` (`TableID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reservations`
--

LOCK TABLES `Reservations` WRITE;
/*!40000 ALTER TABLE `Reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `Reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TablesRestaurant`
--

DROP TABLE IF EXISTS `TablesRestaurant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TablesRestaurant` (
  `TableID` int NOT NULL AUTO_INCREMENT,
  `NumeroTable` int NOT NULL,
  `Capacite` int NOT NULL,
  PRIMARY KEY (`TableID`),
  UNIQUE KEY `NumeroTable` (`NumeroTable`),
  KEY `IDX_Tables_NumeroTable` (`NumeroTable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TablesRestaurant`
--

LOCK TABLES `TablesRestaurant` WRITE;
/*!40000 ALTER TABLE `TablesRestaurant` DISABLE KEYS */;
/*!40000 ALTER TABLE `TablesRestaurant` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-29 14:19:32
